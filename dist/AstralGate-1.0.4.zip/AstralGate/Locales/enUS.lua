-- 英文为所有非简体中文客户端的回退语言。
local _, addon = ...
addon.L = {}
local L = addon.L
L["housingAlliance"] = "Alliance Home"
L["housingHorde"] = "Horde Home"
L["housingReturn"] = "Return to Previous Location"
L["DungeonCompendium"] = "Teleport Compendium"
L["portalHideMissing"] = "Hide missing Teleports"
L["portalHideMissingDesc"] = "Hide teleport entries you have not learned yet."
L["portalShowTooltip"] = "Show tooltip on Teleport buttons"
L["portalShowTooltipDesc"] = "Show helpful tooltips on teleport buttons."
L["recentTeleports"] = "Recently used"
L["showRecentTeleports"] = "Show recently used teleports"
L["showRecentTeleportsDesc"] = "Show successfully used teleports (with an adjustable count) at the top, newest first. History is shared across the account and recorded even while hidden. Unavailable teleports are shown in gray, regardless of Hide missing Teleports."
L["teleportOtherVariants"] = "%d other variants available"
L["teleportsPreferredHearthstone"] = "Preferred Hearthstones"
L["teleportsPreferredHearthstoneRandom"] = "All owned Hearthstones"
L["teleportsRandomHearthstoneBinding"] = "Random Hearthstone"
L["teleportsWorldMapBinding"] = "Toggle World Map Teleport panel"

L["noTeleportsAvailable"] = "No teleports available"
L["searchTeleports"] = "Search teleport names"
L["noTeleportSearchResults"] = "No matching teleports"

L["recentTeleportsCount"] = "Recently used count"

L["recentTeleportsHidden"] = "Hide"

L["recentTeleportsMenu"] = "Show recent teleports"

L["teleportsSelectOnFirstOpen"] = "Auto-select on first open"
L["teleportsSelectOnFirstOpenDesc"] = "Switch only on the first map open after login or UI reload. Later opens preserve your tab selection. If unavailable on the first open, do not retry."
